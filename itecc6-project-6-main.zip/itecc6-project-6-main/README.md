# Application Development and Emerging Technologies

## Folder Structure
- **express-server**: contains the server application written in Express
- **mobile-client**: contains the mobile application written in React Native
- **web-client**: contains the web application written in React